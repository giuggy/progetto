#ifndef __SORT__
#define __SORT__

#include <stdlib.h>

void sortArrayOfString(char** strings, size_t numLines);
size_t findAndRemove(char** strings, char* s, size_t numLines);

#endif
